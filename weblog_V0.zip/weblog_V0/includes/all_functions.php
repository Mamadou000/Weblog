<?php
function getPublishedPosts() {
 global $conn;
 $sql = "SELECT * FROM posts WHERE published=true";
 $result = mysqli_query($conn, $sql);
 $posts = mysqli_fetch_all($result, MYSQLI_ASSOC);
 return $posts;

 
}?>

<?php function DisplayPosts($posts){
    foreach ($posts as $post):  ?>
        <div class="post">
            
            <img src="<?php echo $post['image']; ?>" class="post_image" alt="Post Image">
            <h3 class="post_info"><?php echo $post['title']; ?></h3>
            <p class="post_info"><?php echo $post['content']; ?></p>
        </div>
  <?php endforeach;
}?>

